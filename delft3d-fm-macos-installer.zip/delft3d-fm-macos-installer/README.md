# Delft3D FM native Apple Silicon installer

Build the community Apple Silicon port of Delft3D FM locally, with a small Python launcher for model runs. This repository distributes setup scripts and dependency records, **not a portable binary or the Deltares Windows graphical interface**. It is not an official Deltares macOS release.

The native build and installed kernel were executed successfully on Apple Silicon. The packaged verification workflow passed 361 upstream unit tests and all five analytic hydrodynamic benchmarks; one upstream test remains disabled. See [VERIFICATION.md](VERIFICATION.md) for the platform and evidence. These checks do not validate sediment transport, vegetation effects or a particular delta experiment.

## Requirements

- Apple Silicon Mac running macOS, Xcode Command Line Tools and Homebrew.
- An existing Python 3.13 interpreter, selected from your environment registry where available.
- Internet access for the pinned source archive, Python packages and native dependency builds; substantial free disk space for source, Conan packages and the full build.

Install the native dependencies:

```sh
brew install gcc cmake ninja open-mpi openblas boost libxml2 precice googletest pugixml xerces-c pkgconf libomp
```

Conan builds GDAL, HDF5, NetCDF, PETSc and other pinned dependencies from the source recipes. Do not add an unrelated Homebrew GDAL installation for this installer.

## Build

From this directory, use an existing dedicated profile if present:

```sh
"$HOME/.local/share/python-envs/delft3d-build-py313/bin/python" setup_mac.py
```

For a first installation, replace both placeholder interpreter paths with the same existing absolute Python 3.13 path:

```sh
/absolute/path/to/python3.13 setup_mac.py --bootstrap-python /absolute/path/to/python3.13
```

The bootstrap creates a dedicated central profile only when absent, using [requirements-lock.txt](requirements-lock.txt). It checks an existing profile instead of upgrading it. Register a new profile in your local environment registry if you use one. Do not install this specialised stack into system Python, Anaconda base or a project-local `.venv`.

Default storage is outside cloud-synchronised project folders:

| Component | Location |
| --- | --- |
| Python profile | `~/.local/share/python-envs/delft3d-build-py313` |
| Source | `~/.local/share/delft3d-workspace/source` |
| Build/install | `source/build_fm-suite_release`, with `install` beneath it |
| Native dependencies | `~/.local/share/delft3d-workspace/conan` |

The source archive is downloaded only for a fresh source directory and checked against the pinned SHA256. Unidentified nonempty source directories are refused. Resume preserves the existing build, configures GoogleTest discovery for test time (`PRE_TEST`), builds with six jobs and installs the suite. Discovery at test time avoids a startup timeout observed during simultaneous compilation without changing test acceptance criteria.

**Do not move or delete the source, build or Conan trees after installation.** This port has absolute dependency paths into its build/cache locations. They remain runtime dependencies; copying `install` alone does not produce a portable application. `--workspace` and `--environment` may select different durable locations before building.

## Check and run

```sh
"$HOME/.local/share/python-envs/delft3d-build-py313/bin/python" setup_mac.py --check
"$HOME/.local/share/python-envs/delft3d-build-py313/bin/python" run_fm.py /absolute/path/to/model.mdu
```

The check executes the kernel's `--help`; it is not a simulation. The model launcher invokes `dflowfm --autostartstop`, supports spaces in paths, sets the model directory and library environment, and writes `dflowfm.log` there. `--log` chooses another log; an existing selected log is replaced. Check final model time, outputs and conservation, not just the process exit code.

Run the verification workflow using the dedicated profile:

```sh
"$HOME/.local/share/python-envs/delft3d-build-py313/bin/python" verify_mac.py --output-dir verification-results
```

It runs upstream CTest serially and all five analytic cases using the actual installed engine. The output directory must be new or empty. JSON results and diagnostic logs are retained there, including on failure; large analytic outputs and task caches are cleaned from temporary storage. Reports replace personal paths with labelled placeholders. An explicit `--skip-unit-tests` runs only the analytic suite and labels the report `analytic-only`; it cannot establish that CTest passed. A failed requested check returns a nonzero exit status. Avoid running verification concurrently with compilation or another CTest run in the same build directory.

Record actual outcomes before claiming numerical verification. WAVE ESMF regridding and the GNU-incompatible `io_netcdf_dll` interface are unavailable in this port; FM uses the ordinary Fortran NetCDF interface.

## Reproducibility and attribution

Pinned source: [tdamsma/Delft3D](https://github.com/tdamsma/Delft3D/tree/01bc2f3e53e2d5319696c5ed2b8a74f5ca904220), commit `01bc2f3e53e2d5319696c5ed2b8a74f5ca904220`, a community port derived from [Deltares/Delft3D](https://github.com/Deltares/Delft3D). See [SOURCE.json](SOURCE.json) for the archive identity and [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for licence provenance. Homebrew versions are not frozen by the installer; retain the actual installed versions with your verification record. The Python lock captures package versions for Python 3.13/macOS ARM, not artifact hashes.

The package manifest is [MANIFEST.txt](MANIFEST.txt). It excludes downloaded source, binaries, environments, caches and model outputs. No GitHub upload is performed by these scripts.
