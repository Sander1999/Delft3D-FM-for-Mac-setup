# Verified native runtime

Verified locally on 26 September 2026: native build and installation, installed-kernel help probe, and the packaged `verify_mac.py` full workflow completed successfully. No container or x86 emulation was used.

| Check | Outcome |
| --- | --- |
| Upstream CTest, serial | 361 passed, 0 failed, 1 upstream-disabled test |
| Disabled test | `FF2NFWriterTest.WriteToFile` |
| Analytic lake at rest | Passed |
| Analytic normal-depth channel | Passed |
| Analytic linear seiche | Passed |
| Analytic Stoker dam break | Passed |
| Analytic Thacker basin | Passed |

Platform: macOS 27.0 (26A428), arm64; Apple Clang 21.0.0 (`clang-2100.3.34.2`), Homebrew GNU Fortran 16.2.0, Python 3.13. Source commit and archive SHA256 are recorded in `SOURCE.json`. The kernel reports version `1.2.184.Unknown` because its archive build lacks Git metadata; `Unknown` does not replace the known source archive identity.

The packaged verification workflow ran from 13:21:43 to 13:23:27 UTC. Retained evidence is in [verification/verification-summary.json](verification/verification-summary.json), [verification/analytic-results.json](verification/analytic-results.json) and [verification/ctest.log](verification/ctest.log). The initial report parser treated a JUnit `status="disabled"` attribute as passed; the parser and report were corrected against the CTest log and an isolated disabled-test XML check. This was a reporting correction, not a rerun or modification of numerical results. Analytic case outputs and caches were removed after preserving the results; placeholder paths in reports intentionally refer to that removed scratch.

These checks establish a working installed engine and agreement with the specified upstream analytic hydrodynamic tests under their tolerances. They do not establish accuracy for sediment transport, vegetation, bank erosion, long-term morphodynamics or a particular delta experiment. Those scientific applications need their own conservation and sensitivity checks. No sediment or vegetation validation claim is made by this installer.

The installer scripts were syntax checked; whitespace-safe invocation and refusal of unknown existing source were checked. A completely fresh second-Mac bootstrap has not been independently tested. Homebrew versions can change, and the installed source/build/Conan trees remain required because the port is not relocatable.
